<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="modinatheme">
        <meta name="description" content="">
        <title>REJUVENATE Digital Health</title>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/meanmenu.css">
        <link rel="stylesheet" href="assets/css/odometer.css">
        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/main.css">
    </head>
    <body>
    <?php include("header.php")?>
        <section class="contact-appointment-section section-padding fix">
            <div class="container">
                <div class="contact-appointment-wrapper-5 mb-5">
                    <div class="row">
                       
                        <div class="col-md-12 col-sm-12 col-12">
                         <div class="login-card">
                              <div class="login-logo">
                               <img src="assets/img/logo/logo.png" class="img-fluid">
                             </div>
    <h3>Forgot Password</h3>
    <form>
        <div class="mb-3">
        <label for="password" class="form-label">New Password</label>
        <input type="password" class="form-control" id="password" placeholder="Enter New password">
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="password" placeholder="Enter your confirm password">
      </div>
      
      <button type="submit" class="btn btn-primary w-100">Forgot Now</button>
    </form>
   
  </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
       <?php include("footer.php")?>
    </body>
</html>